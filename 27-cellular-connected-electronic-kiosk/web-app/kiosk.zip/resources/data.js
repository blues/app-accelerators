var cityList = {
  cities: ["Barcelona", "Madrid", "Dublin", "Tokyo"],
};